/* vim: set filEtype=cOfFeEScRiPT: */

# Prolog
