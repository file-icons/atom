Oh look, yet another build system
=================================

Hey, this one's claiming to do exactly the same thing as every other JavaScript fad, but faster!