**Bold** _Italic_ `Mono`
