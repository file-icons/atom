"use strict";

const fs           = require("fs");
const path         = require("path");
const print        = require("print");
const CoffeeScript = require("coffee-script");
const {expect}     = require("chai");


const Icon = require("../lib/icon.js");

describe("Icon config", () => {
	
	describe("Definitions", () => {
		it("accepts strings as patterns", () => {
			const icons = Icon.compile({
				a: {match: ".jpg"},
				b: {match: ".jpg", scope: "js"},
				c: {match: ".jpg", scope: "f", alias: "F"},
				d: {match: ".jpg", scope: "g", interpreter: "j"}
			});
			
			expect(icons[0].match).to.eql(/\.jpg$/i);
			expect(icons[1].scope).to.eql(/\.js$/i);
			expect(icons[2].lang).to.eql(/c|F/i);
			expect(icons[3].interpreter).to.eql(/^j$/);
		});
		
		
		it("serialises icons as JSON", () => {
			const configPath  = path.join(__dirname, "..", "config.cson");
			const configData  = fs.readFileSync(configPath).toString();
			const {fileIcons} = CoffeeScript.eval(configData);
			
			const icons  = Icon.compile(fileIcons);
			const before = icons;
			const after  = Icon.restore(JSON.parse(JSON.stringify(icons)));
			expect(before).to.eql(after);
		});
		
		
		it("merges icons with compatible properties", () => {
			const icons = Icon.compile({
				Foo: {
					icon: "foo",
					match: [
						[".bar", "medium-red", {scope: "c"}],
						[".BAZ", "medium-red"],
						[".quux", "dark-red"]
					]
				}
			});
			expect(icons[0].match).to.eql(/\.bar$|\.BAZ$/i);
			expect(icons[0].colour).to.eql(["medium-red", "medium-red"]);
			expect(icons[0]).to.have.property("scope");
			expect(icons).to.have.lengthOf(2);
		});
		
		
		it("honours case-sensitivity", () => {
			const icons = Icon.compile({
				a: {colour: "dark-red", match: /AbC$/},
				b: {colour: "dark-red", match: "AbC"}
			});
			expect("Abc").to.not.match(icons[0].match);
		});
		
		
		it("honours the noFuzz property", () => {
			const icons = Icon.compile({
				"abcXYZ": {match: ".a", noFuzz: true, scope: "xyz"}
			});
			expect("abc-xyz").to.not.match(icons[0].match)
		});
		
		
		it("honours the noSuffix property", () => {
			const icons = Icon.compile({
				a: {icon: "alpha", match: ".a"},
				b: {icon: "beta",  match: ".b", noSuffix: true}
			});
			
			expect(icons[0].icon).to.equal("alpha-icon");
			expect(icons[1].icon).to.equal("beta");
		});
	});
	

	describe("Colours", () => {
		it("stores colours as two values", () => {
			const icons = Icon.compile({
				a: {match: ".foo", colour: "medium-blue"},
				b: {match: ".bar", colour: ["medium-green"]},
				c: {match: ".qux", colour: ["medium-green", "medium-green"]},
				d: {match: ".die"}
			});
			
			icons.forEach(icon => {
				expect(icon.colour).to.be.an("array");
				expect(icon.colour).to.have.lengthOf(2);
			});
			
			expect(icons[3].colour).to.eql([null, null]);
		});
		
		
		it("substitutes auto-colours with correct shades", () => {
			const icons = Icon.compile({
				a: {match: ".foo", colour: "auto-orange"},
				b: {match: ".bar", colour: "auto-green"}
			});
			
			expect(icons[0].colour).to.eql(["medium-orange", "dark-orange"]);
			expect(icons[1].colour).to.eql(["medium-green", "dark-green"]);
		});
	});

	
	describe("Language names", () => {
		it("gives names to language-specific icons", () => {
			const icons = Icon.compile({
				a: {match: ".a", alias: "Alpha"},
				b: {match: ".b", alias: "Beta", scope: "text.fancy"}
			});
			
			expect(icons[0]).not.to.have.property("lang");
			expect(icons[1]).to.have.property("lang");
		});
		
		
		it("includes config keys in language names", () => {
			const icons = Icon.compile({
				JavaScript: {match: ".js", scope: "js", alias: "ECMAScript"},
				AsciiDoc: {
					icon: "asciidoc",
					scope: "asciidoc",
					match: /\.(?:ad|adoc|asc|asciidoc)$/i,
					colour: "medium-blue"
				}
			});
			expect(icons[0].lang).to.eql(/AsciiDoc/i);
			expect(icons[1].lang).to.eql(/JavaScript|Ecmascript/i);
		});
		
		
		it("ignores config keys of generic icons", () => {
			const icons = Icon.compile({
				a: {generic: true, match: ".a", scope: "foo", alias: "x"},
				b: {generic: true, match: ".b", scope: "bar", alias: "y"}
			});
			expect("a").not.to.match(icons[0].lang);
			expect("b").not.to.match(icons[1].lang);
		});
	});

	
	
	describe("Ordering", () => {
		it("sorts icons by priority", () => {
			const config = {
				a: {match: ".a", colour: "medium-red"},
				z: {match: ".z", colour: "dark-green", priority: 2}
			};
			
			expect(Icon.compile(config)[0].colour[0]).to.equal("dark-green");
			config.z.priority = -2;
			expect(Icon.compile(config)[0].colour[0]).to.equal("medium-red");
		});
		
		
		it("alphabetises icons of equal priority", () => {
			const icons = Icon.compile({
				z: {match: ".z", priority: 2},
				a: {match: ".a", priority: 2},
				j: {match: ".j", priority: 2}
			});
			expect(".a").to.match(icons[0].match);
			expect(".j").to.match(icons[1].match);
			expect(".z").to.match(icons[2].match);
		});
		
		
		it("matches icons with 0 priority last", () => {
			const icons = Icon.compile({
				a: {match: ".a", priority: 0},
				b: {match: ".b", priority: 1}
			});
			expect(".b").to.match(icons[0].match);
		});
	});
});
