var red		=	0xBB,
	green	=	0xFF,
	blue	=	0xDD,
	alpha	=	0x40;


/**
 * Wrapper for creating a new DOM element, optionally assigning it a hash of properties upon construction.
 *
 * @param {String} nodeType - Element type to create.
 * @param {Object} obj - An optional hash of properties to assign the newly-created object.
 * @return {Element}
 */
function New(nodeType, obj){
	var	node	=	document.createElement(nodeType),
		absorb	=	function(a, b){
			for(i in b)
				if(Object(a[i]) === a[i] && Object(b[i]) === b[i])
					absorb(a[i], b[i]);
				else a[i] =	b[i];
		};
	if(obj) absorb(node, obj);
	return node;
}


function dump(message, data){

	/** Shift our arguments if a message string wasn't passed. */
	if(arguments.length < 2)
		data	=	message,
		message	=	"";

	if("number" === typeof data)
		data	=	data.toString(16);

	for(var h, s = "", i = 0, l = data.length; i < l; ++i){
		h	=	data[i].charCodeAt(0).toString(16).toUpperCase();
		s	+=	(h.length < 2 ? "0" : "") + h + " ";
	}

	var line	=	New("li", {
		dataset: {message: message || ""}
	});
	s	=	s.trim().split(" ");

	for(h = "", i = 0, l = s.length; i < l; ++i){
		h += s[i] + " ";
		line.appendChild(
			New("b", { textContent: s[i] })
		);
	}

	console.log(h.trim());
	console.log(data);
	console.log("\n");
	terminal.appendChild(line);
}



var terminal	=	document.body.appendChild(document.createElement("div"));
terminal.id		=	"terminal";
if(!document.getElementsByTagName("link").length){
	(document.head || document.documentElement.firstChild).appendChild(New("link", {
		type:	"text/css",
		rel:	"stylesheet",
		media:	"all",
		href:	"src/css/demo.css"
	}));
}