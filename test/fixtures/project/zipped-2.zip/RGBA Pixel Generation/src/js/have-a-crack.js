/** Retarded debugging functions written while tired, tranquillised, and jetlagged. All good. */
function traceHex(data){
	var str	=	new ByteArray().parse(data).toString();
	console.log(str);
	return str;
}

function fromHex(data){
	return new ByteArray(data).toString();
}

function ByteArray(data){
	this.data	=	!data ? [] : data.replace(/\s/g, "").replace(/(.{2})/g, "$1 ").trim().split(" ").map(function(value, key, $this){
		return String.fromCharCode(parseInt("0x"+value));
	});
}

ByteArray.prototype.parse	=	function(input){
	var	input	=	String.prototype.toString.call(input),
		str		=	"",
		i		=	0,
		l		=	input.length, c;
	for(; i < l; ++i){
		c	=	input.charCodeAt(i).toString(16);
		str	+=	(c.length < 2 ? "0" : "")+c;
	}
	return str;
};

ByteArray.prototype.hexView	=	function(){
	var str	=	"";
	for(var c, i = 0, l = this.data.length; i < l; ++i){
		c	=	this.data[i].charCodeAt(0).toString(16).toUpperCase();
		str	+=	(c.length < 2 ? "0" : "") + c;

		if(!i || (i+1) % 4)	str	+=	" ";
		else				str	+=	" | ";

		if(!(!i || ((i+1) / 6) % 6))
			str	+=	"\n";
	}
	return str;
};

ByteArray.prototype.toString	=	function(){
	var str	=	"";
	for(var i = 0, l = this.data.length; i < l; ++i)
		str	+=	this.data[i];
	return str;
};


function hton(i){
	return String.fromCharCode(i >>> 24, i >>> 16 & 255, i >>> 8 & 255, i & 255);
}

function addle(data){
	for(var	a = 1, b = i = 0, l	= data.length; i < l; ++i)
		a	=	(a + data.charCodeAt(i)) % 65521,
		b	=	(b + a) % 65521;
	return b << 16 | a;
}

function crc32(data){
	var c = ~0;
	for(var i = 0; i < data.length; ++i)
		for(var b = data.charCodeAt(i) | 0x100; b != 1; b >>>= 1)
			c = (c >>> 1) ^ ((c ^ b) & 1 ? 0xedb88320 : 0);
	return ~c;
}

function base64(data){
	/** Base64-encode that bitch. */
	var enc = "", c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	for(var i = 5, n = data.length * 8 + 5; i < n; i += 6)
		enc += c[(data.charCodeAt(~~(i/8)-1) << 8 | data.charCodeAt(~~(i/8))) >> 7 - i%8 & 63];
	for(; enc.length % 4; enc += "=");
	return enc;
}

function first(data){// Starts 12 "columns" in
	return hton(addle(data));
}

function second(data){
	return hton(crc32(data));
}






function rgba(r, g, b, a){
	var	chr		=	String.fromCharCode,
		fill	=	function(mult, str){ return Array(mult+1).join(str || "\0"); },

		/** Binary output */
		img		=	"\x89PNG\15\12\32\12\0\0\0\15IHDR\0\0\0\4\0\0\0\4\10\6\0\0\0\xA9\xF1\x9E~\0\0\0O",

		/** IDAT (Image Data) chunk. */
		idat	=	"IDAT\10\35\1D\0\xBB\xFF",
		data	=	"\1" + chr(r) + chr(g) + chr(b) + chr(a) + fill(12) + "\2" + fill(2, fill(16) + "\2") + fill(16),
		crc1	=	hton(addle(data)),
		crc2	=	hton(crc32(idat + data + crc1));

		/** Stitch the IDAT chunk together and write the IEND chunk to wrap it up. */
		return img + idat+data+crc1+crc2 +	fill(4)+"IEND\xAEB`\x82";
}


/** Now test that shit! */
var img	=	document.createElement("img");
img.src	=	"data:image/png;base64," + base64(rgba(255, 0, 0, 255));
img.alt	=	"";
document.body.appendChild(img);