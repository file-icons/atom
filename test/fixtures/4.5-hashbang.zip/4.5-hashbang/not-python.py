#!/usr/bin/perl

# But a better programming language. Fight me.
